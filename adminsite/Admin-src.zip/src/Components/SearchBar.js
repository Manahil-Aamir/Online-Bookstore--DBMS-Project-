import React from 'react';
import './Styles/SearchBar.css';


function SearchBar({data}){
return(
<div className="search">
     <div className="searchInput">
       <input type='text'  placeholder='Enter here to search' />
       


     </div>

</div>

);
}

export default SearchBar;