import React from 'react';
import './Styles/Header&Footer.css';

function Footer(){
    return (<div class="footer"> 
        
    </div>)
}

export default Footer;