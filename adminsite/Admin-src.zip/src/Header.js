import React from 'react';
import './Styles/Header&Footer.css';

function Header(){
    return (<div className="header"> 
    </div>)
}

export default Header;